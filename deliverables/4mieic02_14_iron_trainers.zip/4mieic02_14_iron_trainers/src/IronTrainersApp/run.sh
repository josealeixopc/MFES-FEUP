cd ./out/production/IronTrainersApp
java -cp ../../../../IronTrainersModel/generated/java/lib/codegen-runtime.jar:. com.mfes.gui.Main