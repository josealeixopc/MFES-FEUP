package com.mfes.gui;

public class Main {

    public static void main(String[] args) {

        CLI cli = new CLI();
        cli.run();

    }
}
