package com.mfes.model;

import java.util.*;
import org.overture.codegen.runtime.*;

@SuppressWarnings("all")
public interface Func_1<T_1, T_2> {
  public abstract T_2 eval(final T_1 param_1);
}
